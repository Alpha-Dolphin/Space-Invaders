/*Ben Elleman*/
#include <stdlib.h>
#include <stdio.h>

#include "typedef.h"

#include "linkedlist.h"

#include "define.h"

#include "altmem.h"

/*My deleteSome function*/
int deleteSome(void *p2head, CriteriaFunction mustGo, void* helper, ActionFunction disposal, FILE* outFile) {
	Node* holder;
	Node** p2p2change = (Node**) p2head;
	int deleted = 0;
	while (*p2p2change != NULL) {
		if (mustGo((**p2p2change).data, NULL)) {
			holder = *p2p2change;
			*p2p2change = (holder->next);
			disposal(holder->data);
			freeNode(holder, outFile);
			deleted++;
			if (outFile) fprintf(outFile, "%d deleted, %d nodes deleted\n"
				,holder->data, deleted);
		} else { 
			p2p2change = &((**p2p2change).next);
		}
	}
	return deleted;
}

/*Function to free an alien*/
void freeNode(void *ptr, FILE* outFile) {
	static int cleared = 0;
	alternative_free(ptr);
	ptr = NULL;
	cleared++;
	/*Haha dereferencing and casting go brrrrrrrrr*/
	if (outFile) fprintf(outFile,"freeNode: %d freed\n", cleared);
}

int comparison(void* d1, void* d2) {
	char *x = (char*) d1;
	char *y = (char*) d2;
	return *x < *y;
}

void disposal(void *d1) {
	char *x = (char*) d1;
	puts(x);
}

int test(void *d1, void* unused) {
	return d1 == "test";
}

void action (void* d1) { 
	char *x = (char*) d1;
	puts(x);
}

int main() {
	void *listHead = NULL;
	insert(&listHead, "test", comparison, stdout);
	insert(&listHead, "test1", comparison, stdout);
	insert(&listHead, "est", comparison, stdout);
	iterate(listHead, action);
	deleteSome(&listHead, test, NULL, disposal, stdout);
	iterate(listHead, action);
	return 0;
}

