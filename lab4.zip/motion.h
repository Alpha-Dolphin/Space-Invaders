/* Ben Elleman */

void boundryOutput(struct alienData aD) ;
void edgeCase(struct alienData* aD) ;
void motion(void *ptr) ;
