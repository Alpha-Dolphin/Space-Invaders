/* Ben Elleman */

void closeFiles(FILE* inFile, FILE* outFile, int argc, char* argv[]) ;
int openFiles(struct simulation *sim, int argc, char *argv[]) ;
int openInput(struct simulation *sim, int argc, char *argv[]) ;
int openOutput(struct simulation *sim, int argc, char *argv[]) ;
