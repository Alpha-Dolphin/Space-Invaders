/* Ben Elleman */

void boltFire(struct simulation *sim) ;
void left(struct simulation *sim) ;
void right(struct simulation *sim) ;
void userControl(struct simulation *sim) ;
