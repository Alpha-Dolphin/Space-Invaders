/* Ben Elleman */

int alienBolt(void *ptr, void *unused) ;
void alienDraw(void *ptr) ;
int comparison(void *d1, void *d2) ;
int deleteAll(void *unusedA, void *unusedB) ;
int escape(void *ptr, void *unused) ;
int isAtZero(void *ptr, void *unused) ;
void tabular(void *ptr) ;
