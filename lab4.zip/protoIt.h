/* Ben Elleman */

void action(void* d1) ;
int comparison(void* d1, void* d2) ;
void iterate(void *head, ActionFunction doThis) ;
int main() ;
int test(void* string, void* unused) ;
