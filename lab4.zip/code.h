/* Ben Elleman */

int readAlien(struct alienData *aD, FILE* inFile, FILE* outFile) ;
int readColor(int data, FILE* outFile) ;
int readLoop(void* simLoc, FILE* inFile, FILE* outFile) ;
int readPoints(int data, FILE* outFile) ;
int readType(int data, FILE* outFile) ;
