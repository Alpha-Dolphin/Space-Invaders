/* Ben Elleman */

void action(void* d1) ;
int comparison(void* d1, void* d2) ;
void insert(struct Node *newnode, struct Node **p2p2change) ;
int main() ;
