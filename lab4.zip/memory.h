/* Ben Elleman */

struct alienData* alienAlloc(FILE* outFile) ;
void alienFree(void *data) ;
