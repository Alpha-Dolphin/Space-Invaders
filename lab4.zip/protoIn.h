/* Ben Elleman */

void action(void* d1) ;
int comparison(void* d1, void* d2) ;
int insert(void *p2head, void *data, ComparisonFunction goesInFrontOf, FILE* outFile) ;
int main() ;
void privateInsert(struct Node *newnode, struct Node **p2p2change, ComparisonFunction goesInFrontOf, FILE* outFile) ;
