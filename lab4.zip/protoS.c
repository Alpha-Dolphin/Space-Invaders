/*Ben Elleman*/
#include <stdlib.h>
#include <stdio.h>

#include "typedef.h"

#include "linkedlist.h"

#include "define.h"

int test(void* string, void* unused) {
	return string == "test";
}

/* sort moves data, not nodes, so head won't change */
void sort(void *hp, ComparisonFunction goesInFrontOf) {
	/*Bubble sort*/
	int swaps;
	Node* head = hp;
	if (head) {
		do {
			swaps = 0;
			while (head->next) {
				if (goesInFrontOf(head->next->data, head->data)) {
					void* temp = head->data;
					head->data = head->next->data;
					head->next->data = temp;
					swaps++;
				}
				head = head->next;
			}
		} while (swaps > 0);
	}
}

int comparison(void* d1, void* d2) {
	char *x = (char*) d1;
	char *y = (char*) d2;
	return *x < *y;
}
			
void action(void* d1) {
	char *x = (char*) d1;
	puts(x);
} 

int main() {
	void *listHead = NULL;
	insert(&listHead, "test1", comparison, stdout);
	insert(&listHead, "rest", comparison, stdout);
	insert(&listHead, "test2", comparison, stdout);
	insert(&listHead, "best", comparison, stdout);
	insert(&listHead, "test3", comparison, stdout);
	sort(listHead, comparison);
	iterate(listHead, action);
	return 0;
}

