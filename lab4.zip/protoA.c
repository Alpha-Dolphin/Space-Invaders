/*Ben Elleman*/

#include <stdlib.h>
#include <stdio.h>

#include "typedef.h"

#include "linkedlist.h"

#include "define.h"

int test(void* string, void* unused) {
	return string == "test";
}

int any(void *head, CriteriaFunction yes, void* unused) {
	int boolean = 0;
	Node *n = (Node*) head;
	while (n != NULL && !boolean) {
		boolean = test(n->data, NULL);
		n = n->next;
	}
	return boolean;
}

int comparison(void* d1, void* d2) {
	char *x = (char*) d1;
	char *y = (char*) d2;
	return *x < *y;
}
			
void action(void* d1) {
	char *x = (char*) d1;
	puts(x);
} 

int main() {
	void *listHead = NULL;
	insert(&listHead, "rest", comparison, stdout);
	insert(&listHead, "best", comparison, stdout);
	printf("Any 'test': %i\n", any(listHead, test, NULL));
	insert(&listHead, "test", comparison, stdout);
	iterate(listHead, action);
	printf("Any 'test': %i\n", any(listHead, test, NULL));
	return 0;
}

