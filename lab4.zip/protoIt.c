/*Ben Elleman*/
#include <stdlib.h>
#include <stdio.h>

#include "typedef.h"

#include "linkedlist.h"

#include "define.h"

int test(void* string, void* unused) {
	return string == "test";
}

int comparison(void* d1, void* d2) {
	char *x = (char*) d1;
	char *y = (char*) d2;
	return *x < *y;
}

void iterate(void *head, ActionFunction doThis) {
	Node *n = (Node*) head;
	while (n != NULL) {
		doThis(n->data);
		n = n->next;
	}
}

void action(void* d1) {
	char *x = (char*) d1;
	puts(x);
}

int main() {
	void *listHead = NULL;
	iterate(listHead, action);
	insert(&listHead, "rest", comparison, stdout);
	insert(&listHead, "best", comparison, stdout);
	insert(&listHead, "test", comparison, stdout);
	iterate(listHead, action);
	return 0;
}
