/* Ben Elleman */

void constGraphics(struct simulation *sim) ;
void finalOutput(const struct simulation *sim) ;
int newSecond(const struct simulation *sim);
void simDelay(struct simulation* sim) ;
void tabOutput(const struct simulation *sim) ;
