/*Ben Elleman*/

#include <stdlib.h>
#include <stdio.h>

#include "typedef.h"

#include "linkedlist.h"

#include "define.h"

void privateInsert(struct Node *newnode, struct Node **p2p2change, ComparisonFunction goesInFrontOf, FILE* outFile) {
	printf("Inserting %d (lives at %p)\n", newnode->data, newnode);
	/* skip nodes with bigger data than data to insert */
	while( *p2p2change != NULL && goesInFrontOf((**p2p2change).data, newnode->data)) {
		printf("Going past %d\n", (**p2p2change).data);
		p2p2change = &((**p2p2change).next);
	}
	/* do the insert: */
	/* make new node next point to what the changing pointer currently points to */
	newnode->next = *p2p2change;
	/* make the pointer to change point to the new node */
	*p2p2change = newnode;
	printf("Setting changed to %p, next to %p\n", *p2p2change, newnode->next);
}

int insert(void *p2head, void *data, ComparisonFunction goesInFrontOf, FILE* outFile) {
	Node **headNode = (Node**) p2head;
	Node *node = malloc(sizeof(Node));
	if (NULL == node) {
		if (1) printf("ERROR: Node failed to allocate\nI AM A PROTOYPE\n");
		return EXIT_FAILURE;
	} else {
		if (1) printf("DIAGNOSTIC: Node allocated\n");
		node->data = data;
		node->next = NULL;
		privateInsert(node, headNode, goesInFrontOf, outFile);
		return EXIT_SUCCESS;
	}
}

int comparison(void* d1, void* d2) {
	char *x = (char*) d1;
	char *y = (char*) d2;
	return ((*x < *y) ? 1 : 0);
}

void action(void* d1) {
	char *x = (char*) d1;
	puts(x);
}

int main() {
	void *listHead = NULL;
	insert(&listHead, "test", comparison, stdout);
	insert(&listHead, "test1", comparison, stdout);
	insert(&listHead, "est", comparison, stdout);
	iterate(listHead, action);
	return 0;
}

