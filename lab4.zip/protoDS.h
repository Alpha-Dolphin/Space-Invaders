/* Ben Elleman */

void action (void* d1) ;
int comparison(void* d1, void* d2) ;
int deleteSome(void *p2head, CriteriaFunction mustGo, void* helper, ActionFunction disposal, FILE* outFile) ;
void disposal(void *d1) ;
void freeNode(void *ptr, FILE* outFile) ;
int main() ;
int test(void *d1, void* unused) ;
