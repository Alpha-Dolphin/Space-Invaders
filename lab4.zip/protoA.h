/* Ben Elleman */

void action(void* d1) ;
int any(void *head, CriteriaFunction yes, void* unused) ;
int comparison(void* d1, void* d2) ;
int main() ;
int test(void* string, void* unused) ;
