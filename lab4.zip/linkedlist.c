/*Ben Elleman*/

#include <stdio.h>

#include "typedef.h"

#include "linkedlist.h"
#include "invaders.h"

#include "altmem.h"
#include "define.h"
#include "debug.h"

#include "llfunc.h"
#include "memory.h"

/*Terse insert*/
void privateInsert(struct Node *newnode, struct Node **p2p2change, ComparisonFunction goesInFrontOf, FILE* outFile) {
	if (VERBOSE && outFile) fprintf(outFile, "Inserting %d (lives at %p)\n", newnode->data, newnode);
	/* skip nodes with bigger data than data to insert */
	while( *p2p2change != NULL && goesInFrontOf((**p2p2change).data, newnode->data)) {
		if (VERBOSE && outFile) fprintf(outFile,"Going past %d\n", (**p2p2change).data);
		p2p2change = &((**p2p2change).next);
	}
	/* do the insert: */
	/* make new node next point to what the changing pointer currently points to */
	newnode->next = *p2p2change;
	/* make the pointer to change point to the new node */
	*p2p2change = newnode;
	if (VERBOSE && outFile) fprintf(outFile, "Setting changed to %p, next to %p\n", *p2p2change, newnode->next);
}

/*My insert function*/
int insert(void *p2head, void *data, ComparisonFunction goesInFrontOf, FILE* outFile) {
	Node **headNode = (Node**) p2head;
	Node *node = allocNode(outFile);
	if (node) {
		node->data = data;
		node->next = NULL;
		privateInsert(node, headNode, goesInFrontOf, outFile);
		return 1;
	} else {
		return 0;
	}
}

/*Mallocs a Node*/
struct Node* allocNode(FILE* outFile) {
	struct Node* ptr;
	static int nodes = 0;
	ptr = alternative_malloc(sizeof(Node));
	if (ptr) {
		nodes++;
		if (outFile) fprintf(outFile, "DIAGNOSTIC: %d Node allocated\n", nodes);
	} else { 
		if (outFile) fprintf(outFile, "ERROR: allocNode: Node failed to allocate\n");
	}
	return ptr;
}

/*My iterate function*/
void iterate(void *head, ActionFunction doThis) {
	Node *n = (Node*) head;
	while (n) {
		doThis(n->data);
		n = n->next;
	}
}

/*My any function*/
int any(void *head, CriteriaFunction yes, void* unused) {
	int boolean = 0;
	Node *n = (Node*) head;
	while (n && !boolean) {
		boolean = yes(n->data, NULL);
		n = n->next;
	}
	return boolean;
}

/*My deleteSome function*/
int deleteSome(void *p2head, CriteriaFunction mustGo, void* helper, ActionFunction disposal, FILE* outFile) {
	Node* holder;
	Node** p2p2change = (Node**) p2head;
	int deleted = 0;
	while (*p2p2change != NULL) {
		if (mustGo((**p2p2change).data, NULL)) {
			holder = *p2p2change;
			*p2p2change = (holder->next);
			disposal(holder->data);
			freeNode(holder, outFile);
			deleted++;
		} else { 
			p2p2change = &((**p2p2change).next);
		}
	}
	return deleted;
}

/*Function to free an alien*/
void freeNode(void *ptr, FILE* outFile) {
	static int cleared = 0;
	alternative_free(ptr);
	ptr = NULL;
	cleared++;
	if (outFile) fprintf(outFile,"freeNode: %d freed\n", cleared);
	/*if (GRAPHICS) sa_status("freeNode: Memory freed\n");*/
}

/* sort moves data, not nodes, so head won't change */
void sort(void *hp, ComparisonFunction goesInFrontOf) {
	/*Bubble sort*/
	int swaps;
	Node* head = hp;
	if (head) {
		do {
			swaps = 0;
			swaps = privateSort(head, goesInFrontOf);
		} while (swaps > 0);
	}
}

/*The inner sort loop*/
int privateSort(Node *head, ComparisonFunction goesInFrontOf) {
	int swaps = 0;
	while (head->next) {
		if (goesInFrontOf(head->next->data, head->data)) {
			void* temp = head->data;
			head->data = head->next->data;
			head->next->data = temp;
			swaps++;
		}
	head = head->next;
	}
	return swaps;
}

/*Disposes of data type in linkedlist*/
void disposal(void *ptr) {
	alienFree(ptr);
}
