/* Ben Elleman */

void action(void* d1) ;
int comparison(void* d1, void* d2) ;
int main() ;
void sort(void *hp, ComparisonFunction goesInFrontOf) ;
int test(void* string, void* unused) ;
